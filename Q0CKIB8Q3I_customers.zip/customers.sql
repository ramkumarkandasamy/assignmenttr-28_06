INSERT INTO
  customers(name, email, customerId)
VALUES
  (1, "Ravi", "ravi123 @gmail.com"),
  (2, "kishan", "kishan11 @gmail.com"),
  (3, "sameer", "sameer44 @gmail.com");