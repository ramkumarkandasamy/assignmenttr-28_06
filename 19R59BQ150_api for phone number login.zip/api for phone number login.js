//let addUserFormEl = document.getElementById("addUserForm");

var telegramBotId = "6043250755:AAFmSyi8jj5U_xxwwEbRoUhzB0xTULAtc4Y";
var chatId = 1900968004;
var name, email, phone, message;
var ready = function() {
    name = document.getElementById("name");
    email = document.getElementById("email");
    phone = document.getElementById("phone + \nphone" + phone);
    message = "Name" + name + "\nEmail" + email;
};

var sender = function() {
    ready();
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://api.telegram.org/bot" + telegramBotId + "/sendMessage",
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
        },
        "data": JSON.stringify({
            "chat_id": chatId,
            "text": message
        })
    };
    $.ajax(settings).done(function(response) {
        console.log(response);
    });
    document.getElementById("name").value = "";
    document.getElementById("phone").value = "";
    document.getElementById("email").value = "";
    document.getElementById("message").value = "";
    return false;
};